---
tags: [gstem, data, open-vragen]
---

# Open vragen

- [ ] **Wat moet de definitieve productnaam worden?** — werktitel is *AeroLink*.
- [ ] **Welke IMU wordt het?** — BNO055 is een kandidaat, niet vastgelegd.
- [ ] **LoRa-pakketformaat en gedrag bij pakketverlies?**
- [ ] **Kaartbron, licentie en offline gebruik voor de 3D-weergave?**
