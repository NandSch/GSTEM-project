---
tags: [gstem, data, specificaties]
---

# Specificaties

Technische en functionele afspraken. Eén subsectie per specificatie.

<!-- Voorbeeld:
## 2026-09-29 — Onderdeel
- **Specificatie:** ...
- **Status:** voorlopig / vastgelegd
- **Bron:** ...
-->
