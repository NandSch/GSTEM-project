---
tags: [gstem, chatlog]
sessie: "(wordt gevuld zodra pi start)"
gestart: "(automatisch)"
---

# Live chat — huidige sessie

> [!abstract] Automatisch logbestand
> Dit bestand wordt live bijgewerkt door de G-Stem logger in `.pi/extensions/gstem-logger.ts`.
> Bewerk het niet handmatig. Oudere sessies staan in `archief/`.
