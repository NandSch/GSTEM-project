---
tags: [gstem, data, links]
---

# Links en bronnen

| Onderwerp | Link / pad | Notitie |
| --- | --- | --- |
| Projectcontext | `CODEXIMPORT/PROJECT_CONTEXT.md` | Oriëntatiedocument G-Stem/GSN |
| Specificaties (concept) | `CODEXIMPORT/G-Stem_specificaties_concept.docx` | Hardware + software |
| Blokschema | `CODEXIMPORT/Blokschema_AeroLink.drawio` | Keten meetmodule → laptop |
| Webdemo | `GSTEMAPPPREVIEWWEB/index.html` | Mock-up laptopapp |
| Documentatie | `docs/` | Overzichten en inventaris |
