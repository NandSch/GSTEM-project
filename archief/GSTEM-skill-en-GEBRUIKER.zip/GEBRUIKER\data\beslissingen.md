---
tags: [gstem, data, beslissingen]
---

# Beslissingen en keuzes

Chronologisch, nieuwste onderaan. Eén subsectie per beslissing.

<!-- Voorbeeld:
## 2026-09-29 — Voorbeeldbeslissing
- **Beslissing:** ...
- **Reden:** ...
- **Gevolg:** ...
-->
