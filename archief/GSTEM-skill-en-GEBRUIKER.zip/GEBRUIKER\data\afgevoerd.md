---
tags: [gstem, data, afgevoerd]
---

# Afgevoerde opties

> [!warning] Alleen opties die we **zeker niet** gebruiken, met reden.

<!-- Voorbeeld:
## 2026-09-29 — Optie X
- **Reden afvoer:** ...
- **Later opnieuw bekijken?** nee
-->
